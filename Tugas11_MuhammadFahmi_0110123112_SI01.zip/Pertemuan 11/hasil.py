from bangun_datar import *

persegi(5)
persegi_panjang(5, 6)
segitiga_sama_sisi(5, 6)
jajar_genjang(5, 6, 7)
lingkaran(5)
belah_ketupat(5, 6, 7)
layang_layang(5, 6, 7, 8)

from oprasiaritmatika import *

penjumlahan(5, 6)
pengurangan(5, 6)
perkalian(6, 6)
pembagian(6, 6)
modulus(5, 6)
akar(5, 6)
pangkat(5, 6)
median(5, 6)
pembulatan(6, 6)
pembagian_bulat(6, 6)