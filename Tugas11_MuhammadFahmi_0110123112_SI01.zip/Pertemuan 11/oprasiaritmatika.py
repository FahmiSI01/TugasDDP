def penjumlahan(bil1, bil2):
    hasil = bil1 + bil2
    print("Hasil penjumlahan: ", hasil)

def pengurangan(bil1, bil2):
    hasil = bil1 - bil2
    print("Hasil pengurangan: ", hasil)

def perkalian(bil1, bil2):
    hasil = bil1 * bil2
    print("Hasil perkalian: ", hasil)

def pembagian(bil1, bil2):
    hasil = bil1 / bil2
    print("Hasil pembagian: ", hasil)

def modulus(bil1, bil2):
    hasil = bil1 % bil2
    print("Hasil modulus: ", hasil)

def akar(bil1, bil2):
    hasil = bil1 ** (1/bil2)
    print("Hasil akar: ", hasil)

def pangkat(bil1, bil2):
    hasil = bil1 ** bil2
    print("Hasil pangkat: ", hasil)

def median(bil1, bil2):
    hasil = (bil1 + bil2) / 2
    print("Hasil median: ", hasil)

def pembulatan(bil1, bil2):
    hasil = bil1 // bil2
    print("Hasil pembulatan: ", hasil)

def pembagian_bulat(bil1, bil2):
    hasil = bil1 // bil2
    print("Hasil pembagian bulat: ", hasil)
