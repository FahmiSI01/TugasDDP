from Gempa import *

Gempa1 = Gempa("Banten", 1.2)
Gempa1.cetak()

Gempa2 = Gempa("Palu", 6.1)
Gempa2.cetak()

Gempa3 = Gempa("Cianjur", 5.1)
Gempa3.cetak()

Gempa4 = Gempa("Jayapura", 3.3)
Gempa4.cetak()

Gempa5 = Gempa("Garut", 4.0)
Gempa5.cetak()


